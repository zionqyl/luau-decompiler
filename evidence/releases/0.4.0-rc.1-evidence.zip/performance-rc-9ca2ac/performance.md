# Release-candidate performance

The release-candidate comparison reruns the preserved v0.2.0 and v0.3.0 executables against the final candidate on the same Windows host and bytecode corpus. Historical timings remain historical. A final report must identify the measured CLI/helper/analyzer binaries, source files, settings, definitions and corpus hashes; preparation alone is not a timing result.

The corpus contains 2,000 independent small inputs, one function with 4,096 updates, and one module containing 512 functions. Source and bytecode hashes are checked before measurement. The minimum comparison includes thread counts 1 and 4, three measured iterations for every input and a one-second calibration target per warm-core row. Output hashes must be deterministic across thread counts. Longer sample counts can be requested without changing the corpus.

## Reproduce

```powershell
. ./scripts/env.ps1
./scripts/benchmark-rc.ps1
./scripts/benchmark-rc.ps1 -Measure
```

The first command validates assets/corpus identities and writes an ignored preparation plan. It does not run timing measurements or update release performance results. Invoke `-Measure` after building and freezing the candidate CLI, allocation helper and validation helper. Obtain the historical baseline executables from their hash-pinned releases, retaining the matching v0.3 analyzer and helpers; the driver verifies their preserved provenance.

The measured command writes `docs/results/performance-rc.json`, compressed public raw reports in `docs/results/performance-rc-raw/`, and full local artifacts beneath `artifacts/performance-rc/`. A started or failed run invalidates prior success. Metadata paths in public reports use `$workspace/` instead of a machine-specific username/root. Raw original report hashes and the normalization are recorded.

## Separate measurements

| Measurement | Work included | Quality claim |
| --- | --- | --- |
| Warm faithful core | Decode, reconstruction and formatting, with typing and validation off | Complete accepted reconstruction only; strict analysis is not run |
| Warm annotated core | Decode, reconstruction, type inference and formatting, with validation off | Annotations emitted; not verified-typed latency |
| Cold CLI | A fresh process, file input, complete reconstruction, output write and host polling overhead | Same validation-off settings as the warm core |
| Strict-check helper | Reconstruction, annotation, final-source parser/compiler and strict analyzer; fresh process per cache mode | Actual strict outcomes retained, including failures; this is distinct from the verified-typed policy |
| Analyzer-result cache | Fresh reconstruction plus an actual analyzer result-cache hit | Cache-hit fields are checked; this is not a service-response cache hit |
| Verified source CLI | PlayerSnapshot source parse, presentation, pinned validation and the required meaningful-typing gate in a fresh CLI process | Success requires the actual verified-typed policy; no compile/decompile round trip |
| Allocation helper | Instrumented single-thread Rust heap events for the same large cases | Allocation counts are separate from uninstrumented timings |

V0.2 provides its faithful default and does not implement the newer typing/analyzer phases. Compatible explicit `typing` and `validation` settings are shared between v0.3 and the candidate. Different reconstructed source and added correctness/provenance work are part of the product cost; identical input does not mean all versions perform identical work.

Core reports include throughput, latency p50/p95/max, parent peak working set, process wall/CPU time and available phase counters. Summed per-stage thread durations are not elapsed wall time. Long-duration phase histogram quantiles are inclusive bounds. Cold measurements do not flush filesystem caches, and their wall time includes process-launch and ten-millisecond polling overhead.

The strict helper begins with a cold analyzer/definition load. Later requests reuse a bounded persistent worker. Separate processes test cache-disabled and cache-enabled modes. Only observed hits count as hits. Every strict failure stays a failure regardless of a successful timing measurement or syntax/compilation result. A missing or failed helper check prevents the measurement run from being published as complete.

Parent-process memory counters exclude external analyzer processes. Process-tree service/analyzer memory and complete adapter transport latency require their separately recorded measurements. Instrumented live-heap counts exclude stacks, allocator metadata, loaded inputs and analyzer processes. They are not operating-system RSS or an aggregate memory guarantee.

The shared host is not isolated from unrelated applications or OS scheduling. Baselines are measured again in the same run; small changes and three-sample tail estimates must be interpreted cautiously. No benchmark executes recovered scripts or establishes behavioral equivalence. The semantic, strict-policy, resource and release gates remain independent requirements.

## Final candidate result

The [final report](results/performance-rc.json) completed on 2026-11-11, 18:07–18:13 CET, using candidate CLI SHA-256 `9ca2acbc626ebb86f2c5c3801db61f1e2d40bd707e197e3e238a32aa1c700bd1`. Report SHA-256 is `394b1736f134c6f283f43bcc0bb099ff5dbecb4751494c4bde19fdf1ddc18d33`. Source, helpers, analyzer, definitions and CLI identities remained unchanged throughout measurement. Thirty warm-core rows, forty-five fresh CLI observations, twelve strict/cache summaries, eight allocation rows and three successful verified-source observations were recorded. Twenty-six compressed raw reports retain configurations, per-input/output identities and actual quality outcomes. The [05a965 pre-optimization run](results/performance-rc-05a965/report.json) remains separate historical evidence with its exact original report and raw archives.

The host was Windows 10.0.26300, Intel i7-11700K with sixteen logical CPUs, Rust 1.99.1. It was heavily shared with a live Roblox client: a selected-process sample during the final run observed approximately 20.6 GiB of client working set. This sample is not a process-tree peak or causal explanation. Scheduling and memory pressure were not isolated, profiles ran sequentially, and small differences should not be attributed exclusively to code changes. The unchanged v0.2 module median moved from 153.03 ms in the earlier run to 166.32 ms in this run, illustrating session variability.

The result is mixed. Faithful small-input throughput improved over v0.3 in this run; annotated small-input and module throughput regressed, while the annotated large-function median improved. The candidate remains slower than the v0.2 faithful baseline. Annotated peak heap and the large-module analyzer-cache path improved. These measurements do not establish a general performance win.

| Small-input profile, validation off | One thread, scripts/s | Four threads, scripts/s |
| --- | ---: | ---: |
| v0.2 faithful | 9,349 | 30,567 |
| v0.3 faithful | 4,454 | 12,618 |
| Candidate faithful | 5,194 | 14,367 |
| v0.3 annotated | 1,026 | 4,036 |
| Candidate annotated | 979 | 3,800 |

| One-thread workload, p50 / p95 milliseconds | v0.2 faithful | v0.3 faithful | Candidate faithful | v0.3 annotated | Candidate annotated |
| --- | ---: | ---: | ---: | ---: | ---: |
| Small input | 0.095 / 0.177 | 0.203 / 0.346 | 0.171 / 0.303 | 0.913 / 1.421 | 0.962 / 1.517 |
| 4,096-update function | 67.73 / 77.62 | 81.47 / 97.57 | 80.15 / 86.79 | 135.13 / 147.22 | 127.74 / 149.71 |
| 512-function module | 166.32 / 181.45 | 191.66 / 204.91 | 198.47 / 258.26 | 312.57 / 324.69 | 327.04 / 339.99 |

The candidate annotated module has four measured samples at one thread and three at four threads; their p95 is the maximum. Other large rows contain the calibrated counts in the report. One-thread module parent peaks were 36.39 MiB for v0.2 faithful, 57.91/58.04 MiB for v0.3/candidate faithful, and 80.95/69.34 MiB for v0.3/candidate annotated.

For the annotated module, per-script mean phase times were respectively v0.3/candidate: decoding 2.23/2.29 ms, reconstruction 150.51/148.19 ms, inference 80.79/97.28 ms, and formatting 69.81/67.74 ms. These are divided phase totals from the one-thread rows, not percentile decompositions. Type inference remains an optimization target; no validation was disabled to improve a claimed verified-typed measurement.

## Strict analysis and verified source

The following medians use four warmed observations per row. Each full cohort contains five observations. Both versions passed strict analysis for the small script and large function. Both failed all ten module observations across the two cache modes, with 1,024 diagnostics in each first module observation. Syntax and compilation passed. The module's timing is not successful verified-typed output.

| Workload | v0.3 uncached / analyzer-cache milliseconds | Candidate uncached / analyzer-cache milliseconds |
| --- | ---: | ---: |
| Small script | 1.569 / 1.005 | 1.542 / 1.252 |
| Large function | 353.77 / 131.08 | 386.95 / 143.86 |
| Large module, strict failed | 7,956.42 / 647.79 | 8,351.90 / 367.20 |

All twenty-four requested warmed cache observations reported actual analyzer-result cache hits. These still reconstruct and format source; they are not service-response cache hits. Fresh first-small-request worker startup took 0.95–1.39 seconds. Later workloads' first observations reused those workers and are not additional cold-worker samples.

The separate PlayerSnapshot source CLI passed the actual verified-typed policy in three fresh processes. End-to-end wall times were 1,761.32, 1,053.64 and 1,015.06 ms. Each included pinned analyzer startup and output files. Parser times were 108/86/88 microseconds; annotation times 21/10/10 microseconds; formatting 15/13/13 microseconds. Validation dominated at 1,492.07/1,005.71/964.93 ms. This is one distinct known source program with three timing repetitions, not broad native-script or executor coverage.

## Allocation and cold CLI behavior

Instrumented annotated module allocation calls fell slightly from 1,513,563 to 1,510,587; peak additional live heap fell from 65,551,224 to 53,563,460 bytes, and requested allocation bytes fell from 232,266,416 to 222,741,019. Annotated large-function peak additional heap fell from 24,370,153 to 20,634,857 bytes while calls fell from 741,223 to 741,101. The counters show reduced retained/requested storage and small allocation-count changes, not a general CPU improvement. Faithful heap peaks were unchanged in these instrumented cases.

A separate [bounded stack-sampling profile](results/constructor-performance-rc.json) identified constructor-use indexing in functions without an eligible prefill declaration. Skipping that work and cloning use-map keys only on insertion reduced 8,800 allocation calls on the same module in the instrumented before/after experiment, with identical output hashes. That experiment has one observation per executable and includes stack-sampling overhead; its timing is diagnostic, not a latency distribution. Its source snapshot and measured helper identities are preserved separately.

Fresh module CLI medians were 195.64 ms for v0.2 faithful, 13,060.41/13,530.24 ms for v0.3 faithful/annotated, and 266.09/401.98 ms for candidate faithful/annotated. V0.3 automatically serialized approximately 19.8/19.9 MB of assumption metadata to stderr; the candidate emitted bounded summaries of approximately one kilobyte for the corresponding samples. This cold-workflow improvement includes the diagnostic-output change and must not be presented as a comparable warm-core speedup.

An initial orchestration attempt used PowerShell `Start-Process` line-based redirection and drained the large legacy stderr exceptionally slowly. That attempt was stopped, retained beneath ignored `artifacts/performance-rc/`, and excluded from the final comparison. The final driver uses binary asynchronous stream copies for cold CLI/helper output. Full legacy diagnostics were retained; no measured quality failure was discarded. The final complete run is beneath `artifacts/performance-rc-9ca2ac/`; `artifacts/performance-rc-final/` contains the earlier 05a965 run.

The `output_hashes_sha256` field in warm rows identifies the original per-thread JSON report containing the output hashes; it is not a hash of only the hash array. Public gzip files normalize workspace metadata paths, and retain original raw report hashes separately. Aggregate service/analyzer memory, deployment latency and executor transport require their own evidence; none is inferred from the parent-only figures here.
