# Release-candidate performance

The release-candidate comparison reruns the preserved v0.2.0 and v0.3.0 executables against the final candidate on the same Windows host and bytecode corpus. Historical timings remain historical. A final report must identify the measured CLI/helper/analyzer binaries, source files, settings, definitions and corpus hashes; preparation alone is not a timing result.

The corpus contains 2,000 independent small inputs, one function with 4,096 updates, and one module containing 512 functions. Source and bytecode hashes are checked before measurement. The minimum comparison includes thread counts 1 and 4, three measured iterations for every input and a one-second calibration target per warm-core row. Output hashes must be deterministic across thread counts. Longer sample counts can be requested without changing the corpus.

## Reproduce

```powershell
. ./scripts/env.ps1
./scripts/benchmark-rc.ps1
./scripts/benchmark-rc.ps1 -Measure
```

The first command validates assets/corpus identities and writes an ignored preparation plan. It does not run timing measurements or update release performance results. Invoke `-Measure` after building and freezing the candidate CLI, allocation helper and validation helper. Obtain the historical baseline executables from their hash-pinned releases, retaining the matching v0.3 analyzer and helpers; the driver verifies their preserved provenance.

The measured command writes `docs/results/performance-rc.json`, compressed public raw reports in `docs/results/performance-rc-raw/`, and full local artifacts beneath `artifacts/performance-rc/`. A started or failed run invalidates prior success. Metadata paths in public reports use `$workspace/` instead of a machine-specific username/root. Raw original report hashes and the normalization are recorded.

## Separate measurements

| Measurement | Work included | Quality claim |
| --- | --- | --- |
| Warm faithful core | Decode, reconstruction and formatting, with typing and validation off | Complete accepted reconstruction only; strict analysis is not run |
| Warm annotated core | Decode, reconstruction, type inference and formatting, with validation off | Annotations emitted; not verified-typed latency |
| Cold CLI | A fresh process, file input, complete reconstruction, output write and host polling overhead | Same validation-off settings as the warm core |
| Strict-check helper | Reconstruction, annotation, final-source parser/compiler and strict analyzer; fresh process per cache mode | Actual strict outcomes retained, including failures; this is distinct from the verified-typed policy |
| Analyzer-result cache | Fresh reconstruction plus an actual analyzer result-cache hit | Cache-hit fields are checked; this is not a service-response cache hit |
| Verified source CLI | PlayerSnapshot source parse, presentation, pinned validation and the required meaningful-typing gate in a fresh CLI process | Success requires the actual verified-typed policy; no compile/decompile round trip |
| Allocation helper | Instrumented single-thread Rust heap events for the same large cases | Allocation counts are separate from uninstrumented timings |

V0.2 provides its faithful default and does not implement the newer typing/analyzer phases. Compatible explicit `typing` and `validation` settings are shared between v0.3 and the candidate. Different reconstructed source and added correctness/provenance work are part of the product cost; identical input does not mean all versions perform identical work.

Core reports include throughput, latency p50/p95/max, parent peak working set, process wall/CPU time and available phase counters. Summed per-stage thread durations are not elapsed wall time. Long-duration phase histogram quantiles are inclusive bounds. Cold measurements do not flush filesystem caches, and their wall time includes process-launch and ten-millisecond polling overhead.

The strict helper begins with a cold analyzer/definition load. Later requests reuse a bounded persistent worker. Separate processes test cache-disabled and cache-enabled modes. Only observed hits count as hits. Every strict failure stays a failure regardless of a successful timing measurement or syntax/compilation result. A missing or failed helper check prevents the measurement run from being published as complete.

Parent-process memory counters exclude external analyzer processes. Process-tree service/analyzer memory and complete adapter transport latency require their separately recorded measurements. Instrumented live-heap counts exclude stacks, allocator metadata, loaded inputs and analyzer processes. They are not operating-system RSS or an aggregate memory guarantee.

The shared host is not isolated from unrelated applications or OS scheduling. Baselines are measured again in the same run; small changes and three-sample tail estimates must be interpreted cautiously. No benchmark executes recovered scripts or establishes behavioral equivalence. The semantic, strict-policy, resource and release gates remain independent requirements.

## Current result

The [final measured report](results/performance-rc.json) completed on 2026-11-11, 17:49–17:55 CET, using candidate CLI SHA-256 `05a9651748135dc1937b7d309ba951e1dd8356b38cf82591d1d449f7ab944996`. Report SHA-256 is `386adba07f7f8889fb7fa95b2a22fdd98aa2ade6d956039f30b4ee8a2e9b17b2`. Source, helpers, analyzer, definitions and CLI identities remained unchanged throughout measurement. Thirty warm-core rows, forty-five fresh CLI observations, twelve strict/cache summaries, eight allocation rows and three successful verified-source observations were recorded. Twenty-six compressed raw reports retain configurations, per-input/output identities and actual quality outcomes.

The host was Windows 10.0.26300, Intel i7-11700K with sixteen logical CPUs, Rust 1.99.1. It was heavily shared with a live Roblox client: session-level samples before the initial attempt and after the final run observed approximately 4.2 GiB and 17.5 GiB of client working set. Those samples are not a process-tree peak or causal explanation. Scheduling and memory pressure were not isolated, profiles ran sequentially, and small differences should not be attributed exclusively to code changes.

The result is mixed. Faithful small-input throughput improved over v0.3 in this run; annotated core CPU time generally regressed. The candidate remains slower than the v0.2 faithful baseline. Annotated peak heap and the large-module analyzer-cache path improved. These measurements do not establish a general performance win.

| Small-input profile, validation off | One thread, scripts/s | Four threads, scripts/s |
| --- | ---: | ---: |
| v0.2 faithful | 9,670 | 30,362 |
| v0.3 faithful | 4,394 | 12,532 |
| Candidate faithful | 4,830 | 14,607 |
| v0.3 annotated | 1,032 | 4,270 |
| Candidate annotated | 983 | 4,163 |

| One-thread workload, p50 / p95 milliseconds | v0.2 faithful | v0.3 faithful | Candidate faithful | v0.3 annotated | Candidate annotated |
| --- | ---: | ---: | ---: | ---: | ---: |
| Small input | 0.092 / 0.171 | 0.212 / 0.346 | 0.185 / 0.333 | 0.916 / 1.395 | 0.973 / 1.478 |
| 4,096-update function | 70.41 / 78.33 | 94.00 / 146.34 | 81.19 / 88.65 | 119.57 / 128.43 | 133.11 / 142.65 |
| 512-function module | 153.03 / 172.35 | 202.13 / 214.47 | 196.22 / 204.56 | 298.96 / 306.62 | 342.35 / 359.72 |

The candidate annotated module has three measured samples; its p95 is the maximum. Other large rows contain the calibrated counts in the report. One-thread module parent peaks were 36.60 MiB for v0.2 faithful, 57.27/57.90 MiB for v0.3/candidate faithful, and 82.15/69.57 MiB for v0.3/candidate annotated.

For the annotated module, per-script mean phase times were respectively v0.3/candidate: decoding 2.18/2.35 ms, reconstruction 145.13/159.44 ms, inference 78.97/96.27 ms, and formatting 66.56/69.63 ms. These are divided phase totals from the one-thread rows, not percentile decompositions. The inference and reconstruction costs remain optimization targets; no validation was disabled to improve a claimed verified-typed measurement.

## Strict analysis and verified source

The following medians use four warmed observations per row. Each full cohort contains five observations. Both versions passed strict analysis for the small script and large function. Both failed all ten module observations across the two cache modes, with 1,024 diagnostics in each first module observation. Syntax and compilation passed. The module's timing is not successful verified-typed output.

| Workload | v0.3 uncached / analyzer-cache milliseconds | Candidate uncached / analyzer-cache milliseconds |
| --- | ---: | ---: |
| Small script | 1.919 / 0.818 | 1.374 / 0.962 |
| Large function | 375.87 / 119.19 | 361.99 / 121.39 |
| Large module, strict failed | 8,095.90 / 544.93 | 7,851.33 / 343.27 |

All twenty-four requested warmed cache observations reported actual analyzer-result cache hits. These still reconstruct and format source; they are not service-response cache hits. Fresh first-small-request worker startup took 1.06–1.45 seconds. Later workloads' first observations reused those workers and are not additional cold-worker samples.

The separate PlayerSnapshot source CLI passed the actual verified-typed policy in three fresh processes. End-to-end wall times were 1,450.45, 1,078.21 and 1,072.37 ms. Each included pinned analyzer startup and output files. Parser times were 773/86/88 microseconds; annotation times 301/13/10 microseconds; formatting 17/16/13 microseconds. Validation dominated at 1,378.12/1,010.89/1,014.40 ms. This is one distinct known source program with three timing repetitions, not broad native-script or executor coverage.

## Allocation and cold CLI behavior

Instrumented annotated module allocation calls increased from 1,513,566 to 1,519,391; peak additional live heap fell from 65,551,224 to 53,563,460 bytes, and requested allocation bytes fell from 232,267,712 to 223,139,521. Annotated large-function peak additional heap fell from 24,370,153 to 20,634,857 bytes while calls increased from 741,223 to 742,681. The counters show reduced retained/requested storage, not fewer allocations or a demonstrated CPU improvement. Faithful heap peaks were unchanged in these instrumented cases.

Fresh module CLI medians were 208.74 ms for v0.2 faithful, 13,399.63/13,039.55 ms for v0.3 faithful/annotated, and 253.91/407.83 ms for candidate faithful/annotated. V0.3 automatically serialized approximately 19.8/19.9 MB of assumption metadata to stderr; the candidate emitted bounded summaries of 1,034/825 bytes for the corresponding first samples. This cold-workflow improvement includes the diagnostic-output change and must not be presented as a comparable warm-core speedup.

An initial orchestration attempt used PowerShell `Start-Process` line-based redirection and drained the large legacy stderr exceptionally slowly. That attempt was stopped, retained beneath ignored `artifacts/performance-rc/`, and excluded from the final comparison. The final driver uses binary asynchronous stream copies for cold CLI/helper output. Full legacy diagnostics were retained; no measured quality failure was discarded. The successful complete run is beneath `artifacts/performance-rc-final/`.

The `output_hashes_sha256` field in warm rows identifies the original per-thread JSON report containing the output hashes; it is not a hash of only the hash array. Public gzip files normalize workspace metadata paths, and retain original raw report hashes separately. Aggregate service/analyzer memory, deployment latency and executor transport require their own evidence; none is inferred from the parent-only figures here.
