# v0.4.0-rc.5 current local comparison review

This independently scoped evidence snapshot covers the local Rust engine, readable output, native performance and browser-local processing. It contains aggregate reports, portable settings and compact identity receipts only.

- Repository source: `6c45359b98dc878c2688f468064d6988687117f9`.
- Local Windows engine: `36c81f2589bda731036dd505886d6676e67bca2f759bf0789d5b08e4feb8cfb4`.
- Portable engine text: `29427015a45d9f790d99bd352233ff71561bd48537be3d9cbfd707c589991ec6`.
- Local native engine gate: `939ee2993ef2d431cd7b9f2073b97395037b69619de21727e134c05f849ad0b7`, passed with 50 report identities.

The native comparison uses newly collected rc.5-session measurements of the immutable published rc.4 `1bcace...` executable. It does not include or repackage old rc.4 supplements. Historical browser values already identified inside the current browser report remain historical, not fresh matched runs.

The three selected retained MM2 buffers were processed statically; no captured game script was executed. The reports separate gameplay modules from the data-only Item module. Button and InventoryService still fail strict/useful-typing gates; Item passes. There is no whole-game or whole-inventory rc.5 coverage claim.

The browser receipt distinguishes the accepted local static export from the actual served Pages runtime. The live check observed 30 Chromium groups at https://zionqyl.github.io/luau-decompiler/ and verifies served runtime identities; it is not a whole-CI-export byte comparison or a claim about untested browsers.

Native runtime packaging, installer staging/update acceptance and a final public Windows release are separate boundaries. They remain pending the current installer-only CI correction and are intentionally not certified here. No runtime/installer case payload or runtime archive is included.

No original bytecode, game source, source snippets, credentials, machine-specific absolute paths, screenshots, logs, binaries, old supplementary archive or third-party package payload is included. No publication was performed while preparing this local bundle. Source, fixtures and public examples remain in the repository under their applicable rights; this archive does not grant rights to game code.

`MANIFEST.json` hashes each content file, including this README. It intentionally does not hash itself or `PRIVACY-AUDIT.json`; the audit hashes the manifest, and the external archive checksum binds every member. The exact canonical report bytes and their original dates are preserved. Compact receipts are newly derived summaries and do not claim to rerun their source checks.

The archive uses an explicit file allowlist and fixed ZIP metadata timestamps. Consult `PRIVACY-AUDIT.json` for checks and limitations. Hashes provide integrity/freshness evidence, not an identity signature or proof of universal correctness.
